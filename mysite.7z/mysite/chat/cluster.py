# -*- coding: utf-8 -*-
"""
Created on Sun Dec  9 04:34:45 2018

@author: plotb
"""
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import sklearn.cluster as cluster
import time



data = np.load('clusterable_data.npy')
