# -*- coding: utf-8 -*-
"""
Редактор Spyder

Это временный скриптовый файл.
"""

strd = "1,2,3,4,5,6,7,8"

a = strd.split(',')
print(a)


